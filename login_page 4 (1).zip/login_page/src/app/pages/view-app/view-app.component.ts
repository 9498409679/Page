import { Component } from '@angular/core';

@Component({
  selector: 'app-view-app',
  standalone: true,
  imports: [],
  templateUrl: './view-app.component.html',
  styleUrl: './view-app.component.css'
})
export class ViewAppComponent {

}
