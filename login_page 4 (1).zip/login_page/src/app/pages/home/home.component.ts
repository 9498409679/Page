import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Route, Router, RouterLink } from '@angular/router';
import { animate, style, transition, trigger } from '@angular/animations';

import { NgFor } from '@angular/common';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule,HttpClientModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
  animations: [
    trigger('fadeIn', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate('600ms', style({ opacity: 1 }))
      ])
    ])
  ]
})
export class HomeComponent {


 

  
loginObj:Login;
constructor(private http:HttpClient,private router:Router){
  this.loginObj=new Login();
}










email: string = '';
password: string = '';

onSubmit() {
  // Handle form submission
  console.log('Form submitted:', this.email, this.password);
}
OnLogin(){
//   debugger;
// this.http.post('https://freeapi.miniprojectideas.com/api/User/Login',this.loginObj).subscribe((res:any)=>{
//   if(res.result){
// alert("Login Success")
// this.router.navigateByUrl('/dashboard')
this.router.navigate(['/signup']);
//   }
//   else{
//     alert(res.message)
//   }
// })
 }
 ForgotPassword(){
  this.router.navigate(['/forgotpassword']);
 }
}
export class Login{
  username: string;
  Password:string;

  constructor(){
    this.username='';
    this.Password='';
  }
  // "EmailId":"abc@gmail.com"
  // "Password":"12378"
}

