import { Routes } from '@angular/router';
import { LayoutComponent } from './pages/layout/layout.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { HomeComponent } from './pages/home/home.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';
import { JobboardComponent } from './pages/jobboard/jobboard.component';
import { ViewAppComponent } from './pages/view-app/view-app.component';



export const routes: Routes = [
    {
        path:'',redirectTo:'login',pathMatch:'full'
    },
    {
        path:'login',
        component:HomeComponent
    },
    {
        path:'',
        component:LayoutComponent,
        children:[
            {
                path:'signup',
                component:DashboardComponent
            }
        ]
    },


    {
        path:'login/:forgotpassword',
        component:ForgotPasswordComponent
    },
    {
        path:'',
        component:LayoutComponent,
        children:[
            {
                path:'login/:forgotpassword',
                component:DashboardComponent
            }
        ]
    },
    
    {
        path:'job',
        component:JobboardComponent
    },
    {
        path:'',
        component:LayoutComponent,
        children:[
            {
                path:'job',
                component:JobboardComponent
            }
        ]
    },
    {
        path:'dashboard',
        component:DashboardComponent
    },
   





    {
        path:'viewapp',
        component:ViewAppComponent
    },

];
